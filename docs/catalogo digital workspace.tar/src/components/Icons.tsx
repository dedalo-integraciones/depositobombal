import React from "react";

type P = { className?: string };

const base = (props: P, children: React.ReactNode, filled = false) => (
  <svg
    viewBox="0 0 24 24"
    fill={filled ? "currentColor" : "none"}
    stroke={filled ? "none" : "currentColor"}
    strokeWidth={1.7}
    strokeLinecap="round"
    strokeLinejoin="round"
    className={props.className ?? "w-5 h-5"}
    aria-hidden="true"
  >
    {children}
  </svg>
);

/* ---------- UI ---------- */
export const IconCheck = (p: P) =>
  base(p, <path d="M4 12.5l5 5L20 6.5" />);

export const IconArrow = (p: P) =>
  base(p, <path d="M4 12h15M13 5.5l6.5 6.5L13 18.5" />);

export const IconArrowDown = (p: P) =>
  base(p, <path d="M12 4v15M5.5 13l6.5 6.5L18.5 13" />);

export const IconDoc = (p: P) =>
  base(
    p,
    <>
      <path d="M6 2.8h8.2L19 7.6V21a.8.8 0 0 1-.8.8H6a.8.8 0 0 1-.8-.8V3.6a.8.8 0 0 1 .8-.8z" />
      <path d="M14 3v5h5M8.6 12h6.8M8.6 15.4h6.8M8.6 18.8h4" />
    </>
  );

export const IconClock = (p: P) =>
  base(
    p,
    <>
      <circle cx="12" cy="12" r="8.4" />
      <path d="M12 7.2V12l3.4 2" />
    </>
  );

export const IconBolt = (p: P) =>
  base(p, <path d="M13 2.5L5 13.5h5.5L11 21.5l8-11h-5.5L13 2.5z" />);

export const IconMobile = (p: P) =>
  base(
    p,
    <>
      <rect x="7" y="2.8" width="10" height="18.4" rx="2.2" />
      <path d="M10.4 18.2h3.2" />
    </>
  );

/* ---------- seguridad ---------- */
export const IconKey = (p: P) =>
  base(
    p,
    <>
      <circle cx="8" cy="15.5" r="4.3" />
      <path d="M11.2 12.3L20 3.5M16.4 7.1l2.8 2.8M13.6 9.9l2.2 2.2" />
    </>
  );

export const IconLock = (p: P) =>
  base(
    p,
    <>
      <rect x="4.6" y="10.2" width="14.8" height="10.4" rx="1.6" />
      <path d="M8 10V7.4a4 4 0 0 1 8 0V10M12 14.4v2.6" />
    </>
  );

export const IconShield = (p: P) =>
  base(
    p,
    <>
      <path d="M12 2.8l7.6 3v6.1c0 4.8-3.2 8-7.6 9.5-4.4-1.5-7.6-4.7-7.6-9.5V5.8L12 2.8z" />
      <path d="M8.7 11.8l2.3 2.3 4.4-4.6" />
    </>
  );

export const IconBackup = (p: P) =>
  base(
    p,
    <>
      <ellipse cx="12" cy="5.6" rx="7.4" ry="2.9" />
      <path d="M4.6 5.6v12.6c0 1.6 3.3 3 7.4 3s7.4-1.4 7.4-3V5.6" />
      <path d="M4.6 12c0 1.6 3.3 3 7.4 3s7.4-1.4 7.4-3" />
    </>
  );

/* ---------- componentes ---------- */
export const IconCode = (p: P) =>
  base(p, <path d="M8.5 7L3.5 12l5 5M15.5 7l5 5-5 5M13.4 4.5l-2.8 15" />);

export const IconDatabase = (p: P) =>
  base(
    p,
    <>
      <ellipse cx="12" cy="5.4" rx="7.4" ry="2.8" />
      <path d="M4.6 5.4v13.2c0 1.5 3.3 2.8 7.4 2.8s7.4-1.3 7.4-2.8V5.4" />
      <path d="M4.6 12c0 1.5 3.3 2.8 7.4 2.8s7.4-1.3 7.4-2.8" />
    </>
  );

export const IconImage = (p: P) =>
  base(
    p,
    <>
      <rect x="3.4" y="4.4" width="17.2" height="15.2" rx="1.8" />
      <circle cx="9" cy="10" r="1.7" />
      <path d="M3.9 17.6l4.9-4.6 3.6 3.3 3-2.7 4.7 4" />
    </>
  );

export const IconUserAuth = (p: P) =>
  base(
    p,
    <>
      <circle cx="9" cy="8" r="3.6" />
      <path d="M3.4 20.4c.5-3.6 2.8-5.6 5.6-5.6s5.1 2 5.6 5.6" />
      <path d="M16.5 7.5l1.6 1.6 3-3.2" />
    </>
  );

export const IconServer = (p: P) =>
  base(
    p,
    <>
      <rect x="3.4" y="4" width="17.2" height="6.4" rx="1.4" />
      <rect x="3.4" y="13.6" width="17.2" height="6.4" rx="1.4" />
      <path d="M6.8 7.2h.01M6.8 16.8h.01M10 7.2h.01M10 16.8h.01" />
    </>
  );

export const IconGlobe = (p: P) =>
  base(
    p,
    <>
      <circle cx="12" cy="12" r="8.4" />
      <path d="M3.6 12h16.8M12 3.6c-2.6 2.3-3.9 5.1-3.9 8.4s1.3 6.1 3.9 8.4c2.6-2.3 3.9-5.1 3.9-8.4S14.6 5.9 12 3.6z" />
    </>
  );

/* ---------- personas / flujos ---------- */
export const IconWrench = (p: P) =>
  base(
    p,
    <path d="M14.2 3.4a5 5 0 0 0-4.9 6.2L3.5 15.4a2.1 2.1 0 0 0 3 3l5.8-5.9a5 5 0 0 0 6.3-6.5L15.2 9.4 12.7 6.9l3.4-3.2a5 5 0 0 0-1.9-.3z" />
  );

export const IconStore = (p: P) =>
  base(
    p,
    <>
      <path d="M4 8.2L5.4 3.6h13.2L20 8.2" />
      <path d="M4 8.2h16v2.2a2.5 2.5 0 0 1-2.6 2.4 2.6 2.6 0 0 1-2.7-2.4 2.6 2.6 0 0 1-2.7 2.4A2.6 2.6 0 0 1 9.3 10.4 2.6 2.6 0 0 1 6.6 12.8 2.5 2.5 0 0 1 4 10.4V8.2z" />
      <path d="M5.4 12.6v7.8h13.2v-7.8M10 20.4v-5h4v5" />
    </>
  );

export const IconBag = (p: P) =>
  base(
    p,
    <>
      <path d="M5 7.6h14l-1 12.8H6L5 7.6z" />
      <path d="M8.8 10.2V6.4a3.2 3.2 0 0 1 6.4 0v3.8" />
    </>
  );

export const IconWhatsApp = (p: P) =>
  base(
    p,
    <>
      <path d="M12 3.4a8.6 8.6 0 0 0-7.4 12.9L3.4 20.6l4.4-1.2A8.6 8.6 0 1 0 12 3.4z" />
      <path d="M8.9 8.6c-.5 2.6 3.8 7 6.5 6.5l.7-1.5-2-1.2-.9.7c-.9-.4-1.8-1.4-2.2-2.3l.7-.9-1.2-2-1.6.7z" />
    </>
  );

/* ---------- rubros ---------- */
export const IconSandwich = (p: P) =>
  base(
    p,
    <>
      <path d="M4 9.5C4 6.5 7.6 4.4 12 4.4s8 2.1 8 5.1H4z" />
      <path d="M4.4 12.4l1.9 1.2 1.9-1.2 1.9 1.2 1.9-1.2 1.9 1.2 1.9-1.2 1.9 1.2 1.8-1.1" />
      <path d="M4 16.1h16v.9a2.4 2.4 0 0 1-2.4 2.4H6.4A2.4 2.4 0 0 1 4 17v-.9z" />
    </>
  );

export const IconFlower = (p: P) =>
  base(
    p,
    <>
      <circle cx="12" cy="8.4" r="2.1" />
      <path d="M12 6.3c-1.6-2.9 1.6-4.6 2.4-2.2 2.6-.7 3.5 2.7.7 3.4 1.7 2.5-1.6 4.2-2.9 1.7M12 6.3c1.6-2.9-1.6-4.6-2.4-2.2-2.6-.7-3.5 2.7-.7 3.4-1.7 2.5 1.6 4.2 2.9 1.7" />
      <path d="M12 10.5V20M12 16.6c0-2.6-2.1-3.9-4.6-3.9.2 2.8 2 4.2 4.6 3.9zm0-2.4c0-2.6 2.1-3.9 4.6-3.9-.2 2.8-2 4.2-4.6 3.9z" />
    </>
  );

export const IconHouse = (p: P) =>
  base(
    p,
    <>
      <path d="M3.8 11L12 3.8 20.2 11" />
      <path d="M6 9.4v10.8h12V9.4" />
      <path d="M10 20.2v-5.4h4v5.4" />
    </>
  );

export const IconBox = (p: P) =>
  base(
    p,
    <>
      <path d="M12 3.2l8 3.7v9.9l-8 3.9-8-3.9V6.9l8-3.7z" />
      <path d="M4.3 7.1l7.7 3.6 7.7-3.6M12 10.7v9.8M8.2 5l7.9 3.7" />
    </>
  );

export const IconPizza = (p: P) =>
  base(
    p,
    <>
      <path d="M12 3.4c4.6 0 8.4 1.7 9.4 2.8L12 21 2.6 6.2c1-1.1 4.8-2.8 9.4-2.8z" />
      <circle cx="10" cy="8" r="1.15" />
      <circle cx="14.4" cy="10.4" r="1.15" />
      <circle cx="11.2" cy="13.4" r="1.15" />
    </>
  );

export const IconCar = (p: P) =>
  base(
    p,
    <>
      <path d="M5 13.2L6.6 8a2 2 0 0 1 1.9-1.4h7A2 2 0 0 1 17.4 8l1.6 5.2" />
      <path d="M4 13.2h16a1 1 0 0 1 1 1v3.2h-2.6M3 17.4V14.2a1 1 0 0 1 1-1M6.6 17.4h10.8" />
      <circle cx="7.2" cy="17.4" r="1.9" />
      <circle cx="16.8" cy="17.4" r="1.9" />
    </>
  );

/* ---------- marca de sección ---------- */
export const SectionMark = ({ n }: { n: string }) => (
  <span className="inline-flex items-center justify-center w-9 h-9 border-2 border-ink text-ink font-mono text-[13px] font-semibold bg-paper">
    {n}
  </span>
);
