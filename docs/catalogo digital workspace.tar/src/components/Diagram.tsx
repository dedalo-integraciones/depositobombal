import { useState } from "react";

type NodeId =
  | "landing"
  | "catalogo"
  | "panel"
  | "firebase"
  | "cloudinary"
  | "vercel";

interface NodeData {
  label: string;
  access: string;
  accessTone: "mint" | "signal" | "cyan";
  tech: string;
  cost: string;
  desc: string;
}

const NODES: Record<NodeId, NodeData> = {
  landing: {
    label: "Landing Page",
    access: "PÚBLICA",
    accessTone: "mint",
    tech: "Next.js + Vercel",
    cost: "$0/mes",
    desc: "La cara del negocio: identidad de marca, información de contacto y acceso directo al catálogo. Cada cliente tiene la suya con su propio dominio.",
  },
  catalogo: {
    label: "Catálogo",
    access: "PÚBLICO",
    accessTone: "mint",
    tech: "Firestore en tiempo real",
    cost: "$0/mes",
    desc: "Vitrina de productos con foto, precio y descripción, siempre actualizada. El comprador contacta al negocio por WhatsApp con un solo clic.",
  },
  panel: {
    label: "Panel Admin",
    access: "PRIVADO",
    accessTone: "signal",
    tech: "Firebase Auth",
    cost: "$0/mes",
    desc: "Acceso exclusivo del cliente con email y contraseña. Agrega, edita y elimina productos; los cambios se reflejan al instante en el catálogo público.",
  },
  firebase: {
    label: "Firebase",
    access: "DATOS + AUTH",
    accessTone: "cyan",
    tech: "Firestore · Storage · Auth",
    cost: "Free tier",
    desc: "El corazón del sistema: almacena productos y configuración por cliente, autentica al administrador y guarda las fotografías (hasta 5 GB gratis).",
  },
  cloudinary: {
    label: "Cloudinary",
    access: "IMÁGENES",
    accessTone: "cyan",
    tech: "CDN de medios",
    cost: "Free tier",
    desc: "Optimiza y sirve las fotos de productos con transformación automática. Alternativa directa: Firebase Storage dentro del plan gratuito.",
  },
  vercel: {
    label: "Vercel",
    access: "HOSTING",
    accessTone: "cyan",
    tech: "Edge Network global",
    cost: "$0/mes",
    desc: "Aloja la web del cliente con HTTPS automático, CDN global y despliegue continuo desde el repositorio. Sin servidores que administrar.",
  },
};

const LINES: { d: string }[] = [
  { d: "M130 118 C130 158, 200 158, 236 190" },
  { d: "M380 118 C380 150, 320 158, 288 190" },
  { d: "M380 118 C380 150, 440 158, 468 190" },
  { d: "M630 118 C630 150, 560 158, 524 190" },
  { d: "M630 118 C630 166, 380 168, 330 190" },
  { d: "M262 262 C262 292, 330 296, 352 320" },
  { d: "M498 262 C498 292, 430 296, 408 320" },
];

const toneColor: Record<NodeData["accessTone"], string> = {
  mint: "#2fd08f",
  signal: "#ff6a3d",
  cyan: "#8fd3e8",
};

function Node({
  id,
  x,
  y,
  w,
  active,
  onSelect,
}: {
  id: NodeId;
  x: number;
  y: number;
  w: number;
  active: boolean;
  onSelect: (id: NodeId) => void;
}) {
  const n = NODES[id];
  return (
    <g
      className={`node-box ${active ? "is-active" : ""}`}
      onClick={() => onSelect(id)}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onSelect(id);
        }
      }}
      aria-label={`${n.label} — ${n.access}`}
    >
      <rect
        x={x}
        y={y}
        width={w}
        height={72}
        rx={4}
        fill={active ? "#14293f" : "#101f33"}
        stroke={active ? "#ff6a3d" : "rgba(143,211,232,0.35)"}
        strokeWidth={active ? 2 : 1.2}
      />
      <rect x={x} y={y} width={4} height={72} fill={toneColor[n.accessTone]} />
      <text
        x={x + 18}
        y={y + 32}
        fill="#f1f2ed"
        style={{ font: "700 17px Archivo, sans-serif", fontStretch: "112%" }}
      >
        {n.label}
      </text>
      <text
        x={x + 18}
        y={y + 53}
        fill={toneColor[n.accessTone]}
        style={{ font: "600 10.5px 'IBM Plex Mono', monospace", letterSpacing: "0.12em" }}
      >
        {n.access}
      </text>
    </g>
  );
}

export default function Diagram() {
  const [active, setActive] = useState<NodeId>("firebase");
  const n = NODES[active];

  return (
    <div className="grid lg:grid-cols-[1.6fr_1fr] gap-6 items-stretch">
      {/* plano */}
      <div className="relative border border-ink/15 bg-deep blueprint-grid-dark overflow-hidden">
        <div className="flex items-center justify-between px-4 py-2.5 border-b border-cyanline/20">
          <span className="font-mono text-[11px] tracking-[0.18em] text-cyanline/80">
            PLANO ARQ-01 · PLATAFORMA POR CLIENTE
          </span>
          <span className="hidden sm:flex items-center gap-4 font-mono text-[10.5px] tracking-widest text-cyanline/60">
            <span className="flex items-center gap-1.5">
              <i className="w-2 h-2 rounded-full bg-[#2fd08f] inline-block" /> PÚBLICO
            </span>
            <span className="flex items-center gap-1.5">
              <i className="w-2 h-2 rounded-full bg-[#ff6a3d] inline-block" /> PRIVADO
            </span>
            <span className="flex items-center gap-1.5">
              <i className="w-2 h-2 rounded-full bg-cyanline inline-block" /> INFRA
            </span>
          </span>
        </div>
        <div className="overflow-x-auto">
          <svg viewBox="0 0 760 420" className="w-full min-w-[620px]" role="img" aria-label="Diagrama de arquitectura: landing, catálogo y panel admin sobre Firebase, Cloudinary y Vercel">
            {/* capa: conexiones */}
            <g fill="none" stroke="rgba(143,211,232,0.5)" strokeWidth="1.6">
              {LINES.map((l, i) => (
                <path key={i} d={l.d} className="flow-line" />
              ))}
            </g>
            <Node id="landing" x={30} y={46} w={200} active={active === "landing"} onSelect={setActive} />
            <Node id="catalogo" x={280} y={46} w={200} active={active === "catalogo"} onSelect={setActive} />
            <Node id="panel" x={530} y={46} w={200} active={active === "panel"} onSelect={setActive} />
            <Node id="firebase" x={140} y={190} w={240} active={active === "firebase"} onSelect={setActive} />
            <Node id="cloudinary" x={420} y={190} w={200} active={active === "cloudinary"} onSelect={setActive} />
            <Node id="vercel" x={270} y={320} w={220} active={active === "vercel"} onSelect={setActive} />

            {/* etiquetas de capa */}
            <text x={30} y={30} fill="rgba(143,211,232,0.45)" style={{ font: "500 10px 'IBM Plex Mono', monospace", letterSpacing: "0.2em" }}>
              CAPA PÚBLICA + ADMIN
            </text>
            <text x={140} y={178} fill="rgba(143,211,232,0.45)" style={{ font: "500 10px 'IBM Plex Mono', monospace", letterSpacing: "0.2em" }}>
              SERVICIOS
            </text>
            <text x={270} y={308} fill="rgba(143,211,232,0.45)" style={{ font: "500 10px 'IBM Plex Mono', monospace", letterSpacing: "0.2em" }}>
              DESPLIEGUE
            </text>
          </svg>
        </div>
        <p className="px-4 pb-3 font-mono text-[10.5px] text-cyanline/50 tracking-wide">
          ▸ Clic en cualquier nodo para inspeccionar su función y costo.
        </p>
      </div>

      {/* ficha del nodo */}
      <aside className="border border-ink/15 bg-paper flex flex-col">
        <div className="px-5 pt-4 pb-3 border-b border-ink/10 flex items-center justify-between gap-3">
          <span className="font-mono text-[11px] tracking-[0.18em] text-ink-soft">
            FICHA DE NODO
          </span>
          <span
            className="font-mono text-[10.5px] font-semibold tracking-[0.14em] px-2 py-0.5 border"
            style={{
              color: active === "panel" ? "#c73a15" : active === "landing" || active === "catalogo" ? "#0c7a50" : "#0e6a8a",
              borderColor: "currentColor",
            }}
          >
            {n.access}
          </span>
        </div>
        <div key={active} className="tab-panel px-5 py-5 flex-1">
          <h4 className="display-heavy text-2xl">{n.label}</h4>
          <p className="mt-3 text-[15px] leading-relaxed text-ink-soft">{n.desc}</p>
          <dl className="mt-5 space-y-2.5">
            <div className="flex items-baseline justify-between gap-4 border-t border-dashed border-ink/20 pt-2.5">
              <dt className="font-mono text-[11px] tracking-[0.16em] text-ink-soft">TECNOLOGÍA</dt>
              <dd className="font-mono text-[12.5px] font-semibold text-right">{n.tech}</dd>
            </div>
            <div className="flex items-baseline justify-between gap-4 border-t border-dashed border-ink/20 pt-2.5">
              <dt className="font-mono text-[11px] tracking-[0.16em] text-ink-soft">COSTO</dt>
              <dd className="font-mono text-[12.5px] font-semibold text-mint text-right">{n.cost}</dd>
            </div>
          </dl>
        </div>
        <div className="px-5 py-3 border-t border-ink/10 bg-paper-2/70">
          <p className="font-mono text-[11px] text-ink-soft tracking-wide">
            Stack completo por cliente: <span className="font-semibold text-ink">Firebase + Vercel + Next.js</span>
          </p>
        </div>
      </aside>
    </div>
  );
}
