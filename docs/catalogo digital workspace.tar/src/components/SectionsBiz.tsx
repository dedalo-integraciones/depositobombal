import { useState } from "react";
import { Section, SectionHeader, MonoTag } from "./ui";
import { useCountUp } from "../hooks";
import {
  IconSandwich,
  IconFlower,
  IconHouse,
  IconBox,
  IconPizza,
  IconCar,
  IconCheck,
  IconWrench,
  IconStore,
  IconBag,
} from "./Icons";

/* ---------------- 07 · modelo de costos ---------------- */

const BARRAS = [
  { label: "Base de datos", limite: "1 GB", uso: "~5 MB · 50 productos", pct: "<1%", fill: 3 },
  { label: "Storage de imágenes", limite: "5 GB", uso: "~25 MB · 50 productos", pct: "<1%", fill: 3 },
  { label: "Ancho de banda", limite: "1 GB/mes", uso: "~100 MB/mes", pct: "10%", fill: 10 },
];

function CounterBlock() {
  const clientes = useCountUp(300, 1600);
  return (
    <div className="grid grid-cols-3 divide-x-2 divide-ink/70 border-2 border-ink bg-paper">
      <div className="px-4 py-5 text-center">
        <div className="display-heavy text-[clamp(1.8rem,3.5vw,2.8rem)] leading-none text-signal-dark">
          $0
        </div>
        <div className="mt-2 font-mono text-[10px] tracking-[0.18em] text-ink-soft">COSTO / MES</div>
      </div>
      <div className="px-4 py-5 text-center">
        <div className="display-heavy text-[clamp(1.8rem,3.5vw,2.8rem)] leading-none text-ink">
          +<span ref={clientes.ref}>{clientes.value}</span>
        </div>
        <div className="mt-2 font-mono text-[10px] tracking-[0.18em] text-ink-soft">CLIENTES SOPORTADOS</div>
      </div>
      <div className="px-4 py-5 text-center">
        <div className="display-heavy text-[clamp(1.8rem,3.5vw,2.8rem)] leading-none text-mint">1–2 h</div>
        <div className="mt-2 font-mono text-[10px] tracking-[0.18em] text-ink-soft">POR DESPLIEGUE</div>
      </div>
    </div>
  );
}

export function Costos() {
  return (
    <Section id="costos" className="border-t-2 border-ink">
      <SectionHeader
        num="07"
        kicker="MODELO DE COSTOS"
        title="El free tier alcanza para cientos de clientes"
        lead="Medido contra los límites gratuitos de Firebase, un catálogo de 50 productos consume menos del 1% de cada recurso."
      />

      <div className="grid lg:grid-cols-[1.35fr_1fr] gap-6 items-start">
        {/* barras de consumo */}
        <div className="reveal border-2 border-ink bg-paper p-6 md:p-8">
          <div className="flex items-center justify-between mb-7">
            <h3 className="display-heavy text-xl">Free tier de Firebase · por cliente</h3>
            <MonoTag tone="mint">CAPACIDAD USADA</MonoTag>
          </div>
          <div className="space-y-7">
            {BARRAS.map((b, i) => (
              <div key={b.label}>
                <div className="flex flex-wrap items-baseline justify-between gap-2 mb-2">
                  <span className="font-display font-bold text-[15px]" style={{ fontStretch: "112%" }}>
                    {b.label}
                  </span>
                  <span className="font-mono text-[11.5px] text-ink-soft">
                    uso <span className="font-semibold text-ink">{b.uso}</span> · límite{" "}
                    <span className="font-semibold text-ink">{b.limite}</span>
                  </span>
                </div>
                <div className="relative h-7 border border-ink/50 bg-paper-2 overflow-hidden">
                  {/* relleno animado */}
                  <div
                    className="bar-fill absolute inset-y-0 left-0 bg-mint"
                    style={{ width: `${Math.max(b.fill, 2.5)}%`, animationDelay: `${i * 180 + 200}ms` }}
                  />
                  {/* marcador de exceso restante */}
                  <div
                    className="absolute inset-y-0 left-0 border-r-2 border-dashed border-ink/30"
                    style={{ width: "100%" }}
                    aria-hidden
                  />
                  <span className="absolute right-2 top-1/2 -translate-y-1/2 font-mono text-[11px] font-semibold text-ink">
                    {b.pct} del límite
                  </span>
                </div>
              </div>
            ))}
            <div className="border border-dashed border-mint bg-mint/10 px-4 py-3 flex items-center justify-between gap-3">
              <span className="font-display font-bold text-[14.5px]" style={{ fontStretch: "112%" }}>
                Autenticación
              </span>
              <span className="font-mono text-[11.5px] text-ink">
                ilimitada · uso: <span className="font-semibold text-mint">1 usuario por cliente</span>
              </span>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="reveal" style={{ transitionDelay: "100ms" }}>
            <CounterBlock />
          </div>
          {/* costos del desarrollador */}
          <div className="reveal border-2 border-ink bg-deep text-paper p-6 blueprint-grid-dark" style={{ transitionDelay: "180ms" }}>
            <h3 className="display-heavy text-lg text-paper">Costos para el desarrollador</h3>
            <dl className="mt-4 space-y-2.5 font-mono text-[12.5px]">
              {[
                { k: "Firebase", v: "$0/mes", mint: true },
                { k: "Vercel", v: "$0/mes", mint: true },
                { k: "Dominio del cliente", v: "pagado por el cliente", mint: false },
              ].map((r) => (
                <div key={r.k} className="flex items-baseline justify-between border-b border-dashed border-cyanline/25 pb-2.5">
                  <dt className="text-cyanline/80">{r.k}</dt>
                  <dd className={r.mint ? "text-mint font-semibold" : "text-paper/85"}>{r.v}</dd>
                </div>
              ))}
              <div className="flex items-baseline justify-between pt-2">
                <dt className="font-semibold tracking-[0.14em] text-[11px]">TOTAL OPERATIVO</dt>
                <dd className="display-heavy text-3xl text-signal">$0<span className="text-base text-cyanline/70 font-mono font-normal">/mes</span></dd>
              </div>
            </dl>
          </div>
        </div>
      </div>
    </Section>
  );
}

/* ---------------- 08 · adaptabilidad por rubro ---------------- */

const RUBROS = [
  {
    id: "sangucheria",
    icon: IconSandwich,
    name: "Sanguchería",
    productos: ["Sándwiches", "Bebidas", "Combos"],
    campos: ["Categoría", "Disponible hoy"],
    ejemplo: "Chicharrón clásico — S/ 12.90",
  },
  {
    id: "floreria",
    icon: IconFlower,
    name: "Florería",
    productos: ["Ramos", "Arreglos", "Coronas"],
    campos: ["Ocasión", "Tamaño"],
    ejemplo: "Ramo primaveral · 24 tallos — S/ 89",
  },
  {
    id: "inmobiliaria",
    icon: IconHouse,
    name: "Inmobiliaria",
    productos: ["Propiedades", "Alquileres"],
    campos: ["Dormitorios", "Baños", "m²"],
    ejemplo: "Dpto. Miraflores · 3 hab · 96 m²",
  },
  {
    id: "mayorista",
    icon: IconBox,
    name: "Mayorista",
    productos: ["Cajas", "Paquetes", "Lotes"],
    campos: ["Precio por volumen"],
    ejemplo: "Caja ×24 unid. — desde S/ 3.10 c/u",
  },
  {
    id: "restaurante",
    icon: IconPizza,
    name: "Restaurante",
    productos: ["Platos", "Bebidas", "Postres"],
    campos: ["Categoría", "Tiempo de preparación"],
    ejemplo: "Pizza artesanal · 20 min — S/ 38",
  },
  {
    id: "concesionaria",
    icon: IconCar,
    name: "Concesionaria",
    productos: ["Vehículos nuevos", "Seminuevos"],
    campos: ["Año", "Kilometraje", "Transmisión"],
    ejemplo: "SUV 2023 · 18 000 km · Mecánico",
  },
];

export function Rubros() {
  const [sel, setSel] = useState(0);
  const r = RUBROS[sel];

  return (
    <Section id="rubros" className="border-t-2 border-ink bg-paper-2/60">
      <SectionHeader
        num="08"
        kicker="ADAPTABILIDAD POR RUBRO"
        title="La misma arquitectura, seis negocios distintos"
        lead="Lo que cambia entre un rubro y otro no es el código: es la configuración — productos típicos y campos adicionales."
      />

      <div className="reveal grid lg:grid-cols-[300px_1fr] border-2 border-ink bg-paper overflow-hidden">
        {/* selector */}
        <div className="border-b-2 lg:border-b-0 lg:border-r-2 border-ink divide-y divide-ink/15" role="tablist" aria-label="Rubros">
          {RUBROS.map((x, i) => {
            const I = x.icon;
            const active = i === sel;
            return (
              <button
                key={x.id}
                role="tab"
                aria-selected={active}
                onClick={() => setSel(i)}
                className={`w-full flex items-center gap-3.5 px-5 py-3.5 text-left transition-all duration-200 group ${
                  active ? "bg-ink text-paper" : "hover:bg-paper-2"
                }`}
              >
                <I className={`w-5.5 h-5.5 shrink-0 transition-colors ${active ? "text-signal" : "text-ink-soft group-hover:text-signal-dark"}`} />
                <span className="font-display font-bold text-[15px] flex-1" style={{ fontStretch: "112%" }}>
                  {x.name}
                </span>
                <span className={`font-mono text-[10px] tracking-[0.14em] ${active ? "text-cyanline" : "text-ink-soft/60"}`}>
                  0{i + 1}
                </span>
              </button>
            );
          })}
        </div>

        {/* ficha */}
        <div key={r.id} className="tab-panel p-6 md:p-9 flex flex-col justify-between gap-8 min-h-[380px]">
          <div>
            <div className="flex items-center gap-4">
              <r.icon className="w-9 h-9 text-signal-dark" />
              <h3 className="display-heavy text-2xl md:text-3xl">{r.name}</h3>
            </div>
            <div className="mt-6 grid sm:grid-cols-2 gap-6">
              <div>
                <div className="font-mono text-[10.5px] tracking-[0.2em] text-ink-soft mb-2.5">
                  PRODUCTOS TÍPICOS
                </div>
                <div className="flex flex-wrap gap-2">
                  {r.productos.map((p) => (
                    <span key={p} className="border-2 border-ink bg-paper px-3 py-1 font-mono text-[12px] font-semibold transition-colors hover:bg-ink hover:text-paper cursor-default">
                      {p}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <div className="font-mono text-[10.5px] tracking-[0.2em] text-ink-soft mb-2.5">
                  CAMPOS ADICIONALES
                </div>
                <div className="flex flex-wrap gap-2">
                  {r.campos.map((c) => (
                    <span key={c} className="border-2 border-signal text-signal-dark px-3 py-1 font-mono text-[12px] font-semibold transition-colors hover:bg-signal hover:text-paper cursor-default">
                      {c}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
          <div className="border-t-2 border-dashed border-ink/25 pt-5 flex flex-wrap items-center justify-between gap-4">
            <div>
              <div className="font-mono text-[10px] tracking-[0.2em] text-ink-soft">EJEMPLO EN CATÁLOGO</div>
              <div className="mt-1 font-mono text-[13.5px] font-semibold text-ink">{r.ejemplo}</div>
            </div>
            <MonoTag tone="signal">SE CONFIGURA · NO SE CODIFICA</MonoTag>
          </div>
        </div>
      </div>
    </Section>
  );
}

/* ---------------- 09 · ventajas competitivas ---------------- */

const VENTAJAS = [
  {
    role: "Para el desarrollador",
    icon: IconWrench,
    style: "bg-deep text-paper border-2 border-ink",
    accent: "text-signal",
    chip: "border-cyanline/40 text-cyanline",
    items: [
      "Un solo código base para todos los clientes",
      "Cero mantenimiento post-venta",
      "Cero costos mensuales",
      "Despliegue rápido: 1–2 horas por cliente",
      "Escalable a cientos de clientes",
    ],
  },
  {
    role: "Para el cliente",
    icon: IconStore,
    style: "bg-paper text-ink border-2 border-ink shadow-[8px_8px_0_0_rgba(14,27,42,0.9)]",
    accent: "text-signal-dark",
    chip: "border-ink/40 text-ink",
    items: [
      "Autonomía total para gestionar su catálogo",
      "Sin conocimientos técnicos requeridos",
      "Sin costos mensuales",
      "Dominio propio con su marca",
      "Actualizaciones en tiempo real",
    ],
  },
  {
    role: "Para el comprador final",
    icon: IconBag,
    style: "bg-signal text-ink border-2 border-ink",
    accent: "text-deep",
    chip: "border-deep/50 text-deep",
    items: [
      "Catálogo siempre actualizado",
      "Experiencia mobile-first",
      "Contacto directo por WhatsApp",
      "Sin necesidad de instalar apps",
    ],
  },
];

export function Ventajas() {
  return (
    <Section id="ventajas" className="border-t-2 border-ink">
      <SectionHeader
        num="09"
        kicker="VENTAJAS COMPETITIVAS"
        title="Cada actor gana algo distinto"
      />
      <div className="grid md:grid-cols-3 gap-6 md:gap-5 items-stretch">
        {VENTAJAS.map((v, i) => (
          <article
            key={v.role}
            className={`reveal ${v.style} p-6 md:p-7 flex flex-col transition-transform duration-300 hover:-translate-y-1.5 ${
              i === 1 ? "md:translate-y-4 md:hover:translate-y-2.5" : ""
            }`}
            style={{ transitionDelay: `${i * 110}ms` }}
          >
            <div className="flex items-center justify-between gap-3">
              <v.icon className={`w-8 h-8 ${v.accent}`} />
              <span className={`font-mono text-[10px] font-semibold tracking-[0.18em] border px-2 py-1 ${v.chip}`}>
                {String(i + 1).padStart(2, "0")}
              </span>
            </div>
            <h3 className="display-heavy text-[22px] mt-4 leading-tight">{v.role}</h3>
            <ul className="mt-5 space-y-3 flex-1">
              {v.items.map((it) => (
                <li key={it} className="flex items-start gap-2.5 text-[13.5px] font-medium leading-snug">
                  <IconCheck className={`w-4 h-4 mt-0.5 shrink-0 ${v.accent}`} />
                  {it}
                </li>
              ))}
            </ul>
          </article>
        ))}
      </div>
    </Section>
  );
}
