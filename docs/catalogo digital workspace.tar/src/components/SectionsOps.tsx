import { useState } from "react";
import type { ComponentType } from "react";
import { Section, SectionHeader, MonoTag } from "./ui";
import {
  IconCode,
  IconDatabase,
  IconImage,
  IconUserAuth,
  IconServer,
  IconGlobe,
  IconLock,
  IconWrench,
  IconStore,
  IconBag,
  IconClock,
  IconBolt,
  IconWhatsApp,
} from "./Icons";

/* ---------------- 04 · componentes ---------------- */

const COMPONENTES = [
  {
    icon: IconCode,
    comp: "Frontend",
    fn: "Interfaz de usuario de las tres superficies",
    tech: "Next.js / React",
    cost: "Gratis",
    tone: "mint" as const,
  },
  {
    icon: IconDatabase,
    comp: "Base de datos",
    fn: "Almacena productos y configuración por cliente",
    tech: "Firebase Firestore",
    cost: "Gratis · 1 GB",
    tone: "mint" as const,
  },
  {
    icon: IconImage,
    comp: "Imágenes",
    fn: "Almacena y sirve las fotos de productos",
    tech: "Firebase Storage",
    cost: "Gratis · 5 GB",
    tone: "mint" as const,
  },
  {
    icon: IconUserAuth,
    comp: "Autenticación",
    fn: "Login privado del cliente administrador",
    tech: "Firebase Auth",
    cost: "Gratis",
    tone: "mint" as const,
  },
  {
    icon: IconServer,
    comp: "Hosting",
    fn: "Aloja la web del cliente con HTTPS y CDN",
    tech: "Vercel",
    cost: "Gratis",
    tone: "mint" as const,
  },
  {
    icon: IconGlobe,
    comp: "Dominio",
    fn: "URL personalizada con la marca del cliente",
    tech: "Cloudflare + Vercel",
    cost: "Según cliente",
    tone: "amber" as const,
  },
];

export function Componentes() {
  return (
    <Section id="componentes" className="border-t-2 border-ink bg-paper-2/60">
      <SectionHeader
        num="04"
        kicker="COMPONENTES TECNOLÓGICOS"
        title="Seis piezas, todas en plan gratuito"
        lead="La selección completa de servicios cabe dentro de los free tiers oficiales. El único costo variable es el dominio, que paga cada cliente."
      />
      <div className="reveal border-2 border-ink bg-paper overflow-x-auto">
        <table className="w-full min-w-[720px] text-left border-collapse">
          <thead>
            <tr className="bg-deep text-paper">
              {["COMPONENTE", "FUNCIÓN", "TECNOLOGÍA", "COSTO"].map((h) => (
                <th key={h} className="px-5 py-3.5 font-mono text-[11px] font-semibold tracking-[0.2em]">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-ink/15">
            {COMPONENTES.map((c) => (
              <tr key={c.comp} className="spec-row group">
                <td className="px-5 py-4">
                  <div className="flex items-center gap-3">
                    <span className="text-ink-soft group-hover:text-signal-dark transition-colors">
                      <c.icon className="w-5 h-5" />
                    </span>
                    <span className="font-display font-bold text-[15.5px]" style={{ fontStretch: "112%" }}>
                      {c.comp}
                    </span>
                  </div>
                </td>
                <td className="px-5 py-4 text-[14px] text-ink-soft">{c.fn}</td>
                <td className="px-5 py-4 font-mono text-[12.5px] font-semibold">{c.tech}</td>
                <td className="px-5 py-4">
                  <MonoTag tone={c.tone === "mint" ? "mint" : "signal"}>{c.cost}</MonoTag>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Section>
  );
}

/* ---------------- 05 · estructura de datos ---------------- */

const TREE = [
  { depth: 0, text: "cliente-{id}/", hl: true },
  { depth: 1, text: "├── configuracion", hl: false, meta: "nombre · logo · colores · whatsapp" },
  { depth: 1, text: "└── productos/", hl: false },
  { depth: 2, text: "├── producto-1", hl: false, meta: "nombre · precio · descripción · foto" },
  { depth: 2, text: "├── producto-2", hl: false },
  { depth: 2, text: "└── producto-N", hl: false },
];

export function EstructuraDatos() {
  return (
    <Section id="datos" className="border-t-2 border-ink">
      <SectionHeader
        num="05"
        kicker="ESTRUCTURA DE DATOS"
        title="Un espacio aislado para cada cliente"
        lead="Dentro del sistema, cada negocio ocupa su propia rama. Nadie más puede leer ni escribir ahí."
      />
      <div className="grid lg:grid-cols-[1.4fr_1fr] gap-6">
        <div className="reveal border-2 border-ink bg-deep blueprint-grid-dark">
          <div className="flex items-center justify-between px-4 py-2.5 border-b border-cyanline/20">
            <span className="font-mono text-[11px] tracking-[0.18em] text-cyanline/80">
              firestore://produccion
            </span>
            <span className="font-mono text-[10px] tracking-[0.16em] text-cyanline/50">
              RUTA POR CLIENTE
            </span>
          </div>
          <div className="p-5 md:p-7 font-mono text-[13px] md:text-[14px] leading-[2.1] text-paper/90 overflow-x-auto">
            {TREE.map((row, i) => (
              <div
                key={i}
                className="tree-row whitespace-nowrap"
                style={{ transitionDelay: `${i * 110 + 150}ms`, paddingLeft: `${row.depth * 28}px` }}
              >
                <span className={row.hl ? "text-signal font-semibold" : ""}>{row.text}</span>
                {row.meta && <span className="text-cyanline/60">  ({row.meta})</span>}
              </div>
            ))}
          </div>
          <div className="px-5 pb-5">
            <div className="border border-dashed border-cyanline/30 px-4 py-3 flex items-start gap-3">
              <IconLock className="w-4.5 h-4.5 text-mint mt-0.5 shrink-0" />
              <p className="font-mono text-[11.5px] leading-relaxed text-cyanline/75">
                <span className="text-mint font-semibold">AISLAMIENTO GARANTIZADO</span> — las reglas de
                seguridad verifican el UID de la sesión contra <span className="text-paper">cliente-{"{id}"}</span> en
                cada lectura y escritura.
              </p>
            </div>
          </div>
        </div>

        <div className="reveal flex flex-col gap-4" style={{ transitionDelay: "120ms" }}>
          <div className="border-2 border-ink bg-paper p-6 flex-1">
            <h3 className="display-heavy text-xl">¿Qué vive en cada rama?</h3>
            <ul className="mt-4 space-y-3">
              {[
                { k: "Configuración", v: "Nombre comercial, logo, paleta de colores y número de WhatsApp del negocio." },
                { k: "Productos", v: "Colección de N documentos: cada uno con nombre, precio, descripción y foto." },
                { k: "Metadatos del rubro", v: "Campos extra definidos por configuración: categoría, m², kilometraje, ocasión…" },
              ].map((x) => (
                <li key={x.k} className="border-l-2 border-signal pl-3.5">
                  <div className="font-mono text-[11px] font-semibold tracking-[0.16em] text-signal-dark">
                    {x.k.toUpperCase()}
                  </div>
                  <p className="mt-0.5 text-[13.5px] leading-relaxed text-ink-soft">{x.v}</p>
                </li>
              ))}
            </ul>
          </div>
          <div className="border-2 border-mint bg-mint/10 px-5 py-4">
            <p className="font-mono text-[12px] leading-relaxed text-ink">
              <span className="font-semibold text-mint">~5 MB</span> de base de datos y{" "}
              <span className="font-semibold text-mint">~25 MB</span> de fotos alcanzan para 50 productos:
              el free tier sobra por cliente.
            </p>
          </div>
        </div>
      </div>
    </Section>
  );
}

/* ---------------- 06 · flujo de trabajo ---------------- */

type Persona = "dev" | "cliente" | "comprador";

const FLUJOS: Record<
  Persona,
  {
    label: string;
    icon: ComponentType<{ className?: string }>;
    badge: string;
    url: string;
    steps: { t: string; d: string }[];
  }
> = {
  dev: {
    label: "Desarrollador",
    icon: IconWrench,
    badge: "VENTA INICIAL · 1–2 H",
    url: "repo://template-base",
    steps: [
      { t: "Crear nuevo proyecto", d: "Nuevo espacio cliente-{id} en Firebase y proyecto en Vercel." },
      { t: "Clonar template base", d: "El mismo código probado que se usa para todos los clientes." },
      { t: "Personalizar marca", d: "Colores, logo y nombre del negocio entran por configuración." },
      { t: "Configurar Firebase y dominio", d: "Reglas de seguridad, auth y DNS apuntando a Vercel." },
      { t: "Desplegar en Vercel", d: "Push al repositorio y la web queda online con HTTPS." },
      { t: "Entregar credenciales", d: "Usuario y contraseña del panel admin, en manos del cliente." },
      { t: "Cobrar fee único", d: "Pago único acordado. Fin de la relación técnica obligatoria." },
    ],
  },
  cliente: {
    label: "Cliente",
    icon: IconStore,
    badge: "USO DIARIO · SIN CÓDIGO",
    url: "micliente.com/admin",
    steps: [
      { t: "Ingresar a su panel", d: "Una ruta privada del tipo micliente.com/admin, solo para él." },
      { t: "Iniciar sesión", d: "Email y contraseña propios; Firebase Auth valida la sesión." },
      { t: "Gestionar productos", d: "Agregar (foto + nombre + precio + descripción), editar o eliminar." },
      { t: "Ver cambios en vivo", d: "El catálogo público se actualiza automáticamente, sin republicar." },
    ],
  },
  comprador: {
    label: "Comprador",
    icon: IconBag,
    badge: "SIN APP · SIN REGISTRO",
    url: "sangucheríaelpollo.com",
    steps: [
      { t: "Ingresar al catálogo", d: "Desde el link del negocio, Google o un código QR en el local." },
      { t: "Navegar productos", d: "Fotos, precios y descripciones siempre actualizadas, mobile-first." },
      { t: "Contactar por WhatsApp", d: "Un clic arma el mensaje con el producto elegido y lo envía al negocio." },
    ],
  },
};

export function Flujos() {
  const [persona, setPersona] = useState<Persona>("dev");
  const f = FLUJOS[persona];

  return (
    <Section id="flujos" className="border-t-2 border-ink bg-paper-2/60">
      <SectionHeader
        num="06"
        kicker="FLUJO DE TRABAJO"
        title="Tres actores, tres recorridos"
        lead="El sistema sirve a tres personas distintas. Cada una toca solo lo que le corresponde."
      />

      <div className="reveal flex flex-wrap gap-2" role="tablist" aria-label="Actores del flujo">
        {(Object.keys(FLUJOS) as Persona[]).map((k) => {
          const I = FLUJOS[k].icon;
          const active = k === persona;
          return (
            <button
              key={k}
              role="tab"
              aria-selected={active}
              onClick={() => setPersona(k)}
              className={`flex items-center gap-2.5 border-2 px-4 py-2.5 font-display font-bold text-[14px] transition-all duration-250 ${
                active
                  ? "bg-ink text-paper border-ink shadow-[4px_4px_0_0_rgba(240,78,35,1)] -translate-y-0.5"
                  : "bg-paper text-ink border-ink/30 hover:border-ink hover:-translate-y-0.5"
              }`}
              style={{ fontStretch: "112%" }}
            >
              <I className={`w-4.5 h-4.5 ${active ? "text-signal" : "text-ink-soft"}`} />
              {FLUJOS[k].label}
            </button>
          );
        })}
      </div>

      <div key={persona} className="tab-panel mt-6 grid lg:grid-cols-[260px_1fr] border-2 border-ink bg-paper">
        <div className="bg-deep text-paper p-6 flex flex-col justify-between gap-6 blueprint-grid-dark">
          <div>
            <div className="font-mono text-[10.5px] tracking-[0.2em] text-cyanline/70 mb-3">
              ROL #{Object.keys(FLUJOS).indexOf(persona) + 1}
            </div>
            <f.icon className="w-10 h-10 text-signal" />
            <h3 className="display-heavy text-2xl mt-3">{f.label}</h3>
            <span className="inline-block mt-3 font-mono text-[10px] font-semibold tracking-[0.16em] border border-cyanline/40 text-cyanline px-2 py-1">
              {f.badge}
            </span>
          </div>
          <div className="font-mono text-[11.5px] text-cyanline/80 border-t border-cyanline/20 pt-3 break-all">
            ▸ {f.url}
          </div>
        </div>
        <ol className="p-6 md:p-8 space-y-0">
          {f.steps.map((s, i) => (
            <li
              key={s.t}
              className="rise-item relative grid grid-cols-[44px_1fr] gap-4 pb-6 last:pb-0"
              style={{ animationDelay: `${i * 90 + 80}ms` }}
            >
              {i < f.steps.length - 1 && (
                <span className="absolute left-[21px] top-11 bottom-0 w-px bg-ink/20" aria-hidden />
              )}
              <span className="w-11 h-11 border-2 border-ink bg-paper flex items-center justify-center font-mono text-[13px] font-semibold z-10 transition-colors duration-300 hover:bg-signal hover:text-paper hover:border-signal">
                {i + 1}
              </span>
              <div className="pt-1">
                <h4 className="font-display font-bold text-[16px]" style={{ fontStretch: "112%" }}>
                  {s.t}
                </h4>
                <p className="mt-0.5 text-[13.5px] leading-relaxed text-ink-soft max-w-lg">{s.d}</p>
              </div>
            </li>
          ))}
        </ol>
      </div>

      <div className="reveal mt-6 flex flex-wrap gap-x-8 gap-y-3">
        {[
          { icon: <IconClock className="w-4 h-4" />, t: "Despliegue completo en 1–2 horas" },
          { icon: <IconBolt className="w-4 h-4" />, t: "Cambios del admin → catálogo en tiempo real" },
          { icon: <IconWhatsApp className="w-4 h-4" />, t: "El pedido llega directo al WhatsApp del negocio" },
        ].map((x) => (
          <span key={x.t} className="flex items-center gap-2.5 font-mono text-[12px] text-ink-soft">
            <span className="text-signal-dark">{x.icon}</span>
            {x.t}
          </span>
        ))}
      </div>
    </Section>
  );
}
