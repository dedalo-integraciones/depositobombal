import Diagram from "./Diagram";
import { Section, SectionHeader, MonoTag } from "./ui";
import { IconBolt, IconLock, IconCode } from "./Icons";

/* ---------------- mocks en miniatura ---------------- */

function MockLanding() {
  return (
    <div className="w-[132px] border-2 border-ink bg-paper shadow-[4px_4px_0_0_rgba(14,27,42,0.85)] transition-transform duration-300 group-hover:-translate-y-1.5 group-hover:-rotate-1">
      <div className="flex items-center gap-1 border-b-2 border-ink px-2 py-1 bg-paper-2">
        <i className="w-1.5 h-1.5 rounded-full bg-signal inline-block" />
        <i className="w-1.5 h-1.5 rounded-full bg-amberline inline-block" />
        <i className="w-1.5 h-1.5 rounded-full bg-mint inline-block" />
      </div>
      <div className="p-2 space-y-1.5">
        <div className="h-6 bg-deep flex items-center px-1.5">
          <span className="font-display text-[7px] font-bold text-paper" style={{ fontStretch: "120%" }}>TU MARCA</span>
        </div>
        <div className="h-1.5 w-3/4 bg-ink/25" />
        <div className="h-1.5 w-1/2 bg-ink/15" />
        <div className="h-4 w-14 bg-signal flex items-center justify-center">
          <span className="font-mono text-[6px] font-semibold text-paper tracking-wider">VER CATÁLOGO</span>
        </div>
      </div>
    </div>
  );
}

function MockCatalogo() {
  return (
    <div className="w-[96px] border-2 border-ink bg-paper shadow-[4px_4px_0_0_rgba(14,27,42,0.85)] transition-transform duration-300 group-hover:-translate-y-1.5 group-hover:rotate-1">
      <div className="border-b-2 border-ink px-2 py-1 flex justify-between items-center bg-deep">
        <span className="font-mono text-[6px] text-paper tracking-widest">CATÁLOGO</span>
        <i className="w-1.5 h-1.5 rounded-full bg-mint inline-block" />
      </div>
      <div className="p-1.5 grid grid-cols-2 gap-1.5">
        {[0, 1, 2, 3].map((i) => (
          <div key={i} className="border border-ink/40">
            <div className={`h-6 ${i % 2 ? "bg-cyanline/50" : "bg-amberline/50"}`} />
            <div className="p-1 space-y-0.5">
              <div className="h-1 w-full bg-ink/30" />
              <div className="h-1 w-2/3 bg-mint" />
            </div>
          </div>
        ))}
      </div>
      <div className="mx-1.5 mb-1.5 h-4 bg-mint flex items-center justify-center">
        <span className="font-mono text-[6px] font-semibold text-paper tracking-wider">PEDIR ✓</span>
      </div>
    </div>
  );
}

function MockPanel() {
  return (
    <div className="w-[132px] border-2 border-ink bg-paper shadow-[4px_4px_0_0_rgba(14,27,42,0.85)] transition-transform duration-300 group-hover:-translate-y-1.5 group-hover:-rotate-1">
      <div className="flex border-b-2 border-ink">
        <div className="w-1/4 bg-deep py-2 flex flex-col items-center gap-1">
          <i className="w-3 h-1 bg-signal inline-block" />
          <i className="w-3 h-1 bg-cyanline/40 inline-block" />
          <i className="w-3 h-1 bg-cyanline/40 inline-block" />
        </div>
        <div className="flex-1 p-1.5 space-y-1">
          {["S/ 12.90", "S/ 8.50", "S/ 24.00"].map((p, i) => (
            <div key={p} className="flex items-center justify-between border border-ink/30 px-1 py-0.5">
              <span className="font-mono text-[6px] text-ink-soft">{p}</span>
              <span className="flex gap-0.5">
                <i className={`w-1.5 h-1.5 inline-block ${i === 1 ? "bg-amberline" : "bg-mint"}`} />
                <i className="w-1.5 h-1.5 bg-signal/70 inline-block" />
              </span>
            </div>
          ))}
          <div className="h-3.5 bg-signal flex items-center justify-center">
            <span className="font-mono text-[6px] font-semibold text-paper tracking-wider">+ NUEVO</span>
          </div>
        </div>
      </div>
      <div className="px-2 py-1 bg-paper-2 border-t border-ink/30 flex items-center gap-1">
        <IconLock className="w-2.5 h-2.5 text-ink-soft" />
        <span className="font-mono text-[6px] tracking-widest text-ink-soft">SESIÓN PRIVADA</span>
      </div>
    </div>
  );
}

/* ---------------- 01 · resumen ---------------- */

const ENTREGABLES = [
  {
    code: "E-01",
    name: "Landing page",
    tag: "PÚBLICA" as const,
    desc: "Con la identidad de marca del cliente: logo, colores, historia y datos de contacto bajo su propio dominio.",
    mock: <MockLanding />,
  },
  {
    code: "E-02",
    name: "Catálogo público",
    tag: "PÚBLICO" as const,
    desc: "Visible para sus compradores: productos con foto, precio y descripción, con pedido directo por WhatsApp.",
    mock: <MockCatalogo />,
  },
  {
    code: "E-03",
    name: "Panel de administración",
    tag: "PRIVADO" as const,
    desc: "Acceso privado para que el cliente gestione sus productos sin depender de nadie: agregar, editar y eliminar.",
    mock: <MockPanel />,
  },
];

export function Resumen() {
  return (
    <Section id="resumen">
      <SectionHeader
        num="01"
        kicker="RESUMEN EJECUTIVO"
        title="Un negocio digital completo, entregado llave en mano"
        lead="Cada cliente recibe una plataforma propia y autosuficiente. Tras la entrega, el desarrollador no vuelve a intervenir: el negocio opera solo."
      />
      <div className="space-y-5">
        {ENTREGABLES.map((e, i) => (
          <article
            key={e.code}
            className="group reveal grid sm:grid-cols-[92px_1fr_auto] gap-5 sm:gap-8 items-center border-2 border-ink bg-paper px-5 sm:px-7 py-5 transition-all duration-300 hover:bg-paper-2 hover:shadow-[8px_8px_0_0_rgba(240,78,35,0.9)] hover:-translate-y-0.5"
            style={{ transitionDelay: `${i * 90}ms` }}
          >
            <div className="font-mono text-[13px] font-semibold tracking-[0.14em] text-signal-dark">
              {e.code}
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-3">
                <h3 className="display-heavy text-xl md:text-2xl">{e.name}</h3>
                <MonoTag tone={e.tag === "PRIVADO" ? "signal" : "mint"}>{e.tag}</MonoTag>
              </div>
              <p className="mt-1.5 text-[14.5px] leading-relaxed text-ink-soft max-w-xl">{e.desc}</p>
            </div>
            <div className="justify-self-start sm:justify-self-end">{e.mock}</div>
          </article>
        ))}
      </div>
      <p className="reveal mt-8 font-mono text-[12px] tracking-wide text-ink-soft border-l-4 border-signal pl-4">
        NOTA DE MODELO — el pago es <span className="font-semibold text-ink">único por cliente</span>. Sin
        mensualidades, sin licencias, sin permanencia.
      </p>
    </Section>
  );
}

/* ---------------- 02 · objetivos ---------------- */

const OBJETIVOS = [
  {
    t: "Presencia digital para cualquier negocio",
    d: "Que un comercio sin conocimientos técnicos pueda tener catálogo propio en internet.",
  },
  {
    t: "Cero dependencia del desarrollador",
    d: "Tras la entrega, el cliente administra todo desde su panel. El desarrollador queda liberado.",
  },
  {
    t: "Cero costos mensuales",
    d: "Ni para el desarrollador ni para el cliente: todo opera sobre planes gratuitos.",
  },
  {
    t: "Escalable a cualquier rubro",
    d: "Comida, inmobiliaria, florería, retail… la misma base se adapta por configuración.",
  },
  {
    t: "Despliegue rápido y replicable",
    d: "Un template base permite lanzar un nuevo cliente en 1–2 horas de trabajo.",
  },
];

export function Objetivos() {
  return (
    <Section id="objetivos" className="border-t-2 border-ink bg-paper-2/60">
      <SectionHeader
        num="02"
        kicker="OBJETIVOS DEL PROYECTO"
        title="Cinco metas que la arquitectura debe cumplir"
      />
      <ol className="divide-y-2 divide-ink/10 border-y-2 border-ink/10">
        {OBJETIVOS.map((o, i) => (
          <li
            key={o.t}
            className="reveal group grid grid-cols-[auto_1fr] md:grid-cols-[72px_auto_1fr] gap-4 md:gap-6 items-start py-5 px-2 md:px-4 transition-colors duration-300 hover:bg-paper"
            style={{ transitionDelay: `${i * 70}ms` }}
          >
            <span className="font-mono text-[13px] font-semibold text-ink-soft/70 pt-1 hidden md:block">
              {String(i + 1).padStart(2, "0")}
            </span>
            <span className="w-9 h-9 border-2 border-mint text-mint flex items-center justify-center shrink-0 transition-all duration-300 group-hover:bg-mint group-hover:text-paper group-hover:rotate-6">
              <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                <path d="M4 12.5l5 5L20 6.5" />
              </svg>
            </span>
            <div>
              <h3 className="display-heavy text-lg md:text-xl leading-tight">{o.t}</h3>
              <p className="mt-1 text-[14px] text-ink-soft max-w-2xl">{o.d}</p>
            </div>
          </li>
        ))}
      </ol>
    </Section>
  );
}

/* ---------------- 03 · arquitectura ---------------- */

export function Arquitectura() {
  return (
    <Section id="arquitectura" className="border-t-2 border-ink">
      <SectionHeader
        num="03"
        kicker="ARQUITECTURA GENERAL"
        title="Tres superficies, un solo backend por cliente"
        lead="Cada plataforma se compone de dos superficies públicas y una privada, servidas por Firebase (datos, auth e imágenes) y desplegadas en Vercel."
      />
      <div className="reveal">
        <Diagram />
      </div>
      <div className="reveal mt-8 grid md:grid-cols-3 gap-4">
        {[
          {
            icon: <IconLock className="w-5 h-5" />,
            t: "Aislamiento por cliente",
            d: "Reglas de seguridad garantizan que cada cliente solo lea y escriba su propio espacio de datos.",
          },
          {
            icon: <IconBolt className="w-5 h-5" />,
            t: "Tiempo real",
            d: "Firestore propaga cada cambio del panel admin al catálogo público en milisegundos.",
          },
          {
            icon: <IconCode className="w-5 h-5" />,
            t: "Un solo código base",
            d: "El mismo template se personaliza por configuración — marca, rubro y campos — nunca por código.",
          },
        ].map((f, i) => (
          <div
            key={f.t}
            className="border border-ink/20 bg-paper px-5 py-4 flex gap-4 items-start transition-all duration-300 hover:border-ink hover:-translate-y-1"
            style={{ transitionDelay: `${i * 80}ms` }}
          >
            <span className="text-signal-dark mt-0.5">{f.icon}</span>
            <div>
              <h4 className="font-display font-bold text-[15px]" style={{ fontStretch: "112%" }}>
                {f.t}
              </h4>
              <p className="mt-1 text-[13.5px] leading-relaxed text-ink-soft">{f.d}</p>
            </div>
          </div>
        ))}
      </div>
    </Section>
  );
}
