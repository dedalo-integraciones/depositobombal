import { Section, SectionHeader } from "./ui";
import {
  IconKey,
  IconLock,
  IconShield,
  IconBackup,
  IconArrow,
  IconCheck,
  IconBolt,
} from "./Icons";

/* ---------------- 10 · seguridad ---------------- */

const SEGURIDAD = [
  {
    icon: IconKey,
    code: "SEC-01",
    t: "Autenticación",
    d: "Cada cliente accede únicamente con sus credenciales. Firebase Auth gestiona sesiones, hash de contraseñas y bloqueos.",
  },
  {
    icon: IconLock,
    code: "SEC-02",
    t: "Aislamiento de datos",
    d: "Las reglas de seguridad de Firebase garantizan que cada cliente solo pueda ver y editar sus propios datos.",
  },
  {
    icon: IconShield,
    code: "SEC-03",
    t: "HTTPS en todo el trayecto",
    d: "Todas las comunicaciones viajan encriptadas de extremo a extremo, del navegador al servicio.",
  },
  {
    icon: IconBackup,
    code: "SEC-04",
    t: "Respaldos automáticos",
    d: "Firebase incluye respaldos y redundancia de infraestructura: el catálogo del cliente nunca depende de una sola máquina.",
  },
];

export function Seguridad() {
  return (
    <Section id="seguridad" dark className="border-t-2 border-ink">
      <SectionHeader
        num="10"
        kicker="SEGURIDAD Y PRIVACIDAD"
        title="Cuatro candados sobre cada plataforma"
        dark
        lead="La confianza del cliente depende de que su catálogo y sus datos sean solo suyos. Estas cuatro capas lo garantizan por diseño."
      />
      <div className="grid sm:grid-cols-2 gap-5">
        {SEGURIDAD.map((s, i) => (
          <article
            key={s.code}
            className="reveal group relative border border-cyanline/25 bg-deep-2/80 p-6 md:p-7 transition-all duration-300 hover:border-cyanline/70 hover:-translate-y-1 overflow-hidden"
            style={{ transitionDelay: `${i * 90}ms` }}
          >
            <span className="absolute -right-3 -top-5 font-mono text-[64px] font-semibold text-cyanline/8 leading-none select-none" aria-hidden>
              {String(i + 1).padStart(2, "0")}
            </span>
            <div className="flex items-center gap-4">
              <span className="w-11 h-11 border border-cyanline/50 text-cyanline flex items-center justify-center transition-all duration-300 group-hover:bg-cyanline group-hover:text-deep">
                <s.icon className="w-5.5 h-5.5" />
              </span>
              <div>
                <div className="font-mono text-[10px] tracking-[0.2em] text-cyanline/60">{s.code}</div>
                <h3 className="display-heavy text-xl text-paper">{s.t}</h3>
              </div>
            </div>
            <p className="mt-4 text-[14px] leading-relaxed text-cyanline/75 max-w-md">{s.d}</p>
          </article>
        ))}
      </div>
    </Section>
  );
}

/* ---------------- 11 · roadmap ---------------- */

const FASES = [
  {
    fase: "FASE 1",
    t: "Template base",
    plazo: "1 SEMANA",
    continuo: false,
    items: [
      "Desarrollo del template reutilizable",
      "Configuración de Firebase",
      "Panel admin funcional",
      "Catálogo público responsive",
    ],
  },
  {
    fase: "FASE 2",
    t: "Primer cliente",
    plazo: "1 SEMANA",
    continuo: false,
    items: [
      "Personalización para cliente piloto",
      "Despliegue y pruebas",
      "Ajustes según feedback",
    ],
  },
  {
    fase: "FASE 3",
    t: "Escalamiento",
    plazo: "CONTINUO",
    continuo: true,
    items: [
      "Documentación del proceso",
      "Templates por rubro",
      "Automatización del despliegue",
    ],
  },
];

export function Roadmap() {
  return (
    <Section id="roadmap" className="border-t-2 border-ink bg-paper-2/60">
      <SectionHeader
        num="11"
        kicker="ROADMAP DE IMPLEMENTACIÓN"
        title="De la base al escalamiento en tres fases"
      />
      <div className="relative">
        {/* línea conectora */}
        <div className="hidden md:block absolute top-[13px] left-[4%] right-[4%] h-0.5 bg-ink/25" aria-hidden>
          <div className="absolute inset-y-0 left-0 w-2/3 bg-signal" />
        </div>
        <ol className="grid md:grid-cols-3 gap-8 md:gap-6">
          {FASES.map((f, i) => (
            <li key={f.fase} className="reveal relative" style={{ transitionDelay: `${i * 130}ms` }}>
              <div className="flex items-center gap-3.5 mb-5">
                <span className={`relative z-10 w-7 h-7 border-2 flex items-center justify-center ${i < 2 ? "bg-signal border-signal" : "bg-paper border-ink"}`}>
                  {f.continuo ? (
                    <i className="w-2 h-2 rounded-full bg-signal inline-block animate-pulse-dot" style={{ animation: "pulsedot 2.2s ease-in-out infinite" }} />
                  ) : (
                    <IconCheck className="w-4 h-4 text-paper" />
                  )}
                </span>
                <span className="font-mono text-[11px] font-semibold tracking-[0.22em] text-ink-soft">{f.fase}</span>
                <span className={`ml-auto font-mono text-[10px] font-semibold tracking-[0.14em] border px-2 py-0.5 ${f.continuo ? "border-signal text-signal-dark" : "border-ink/40 text-ink-soft"}`}>
                  {f.plazo}
                </span>
              </div>
              <div className="border-2 border-ink bg-paper p-6 h-[calc(100%-52px)] transition-all duration-300 hover:shadow-[6px_6px_0_0_rgba(240,78,35,0.9)] hover:-translate-y-1">
                <h3 className="display-heavy text-xl">{f.t}</h3>
                <ul className="mt-4 space-y-2.5">
                  {f.items.map((it) => (
                    <li key={it} className="flex items-start gap-2.5 text-[13.5px] font-medium text-ink">
                      <span className="mt-[7px] w-1.5 h-1.5 bg-signal inline-block shrink-0" />
                      {it}
                    </li>
                  ))}
                </ul>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </Section>
  );
}

/* ---------------- 12 · conclusión ---------------- */

const CONCLUSIONES = [
  { k: "Inversión inicial mínima", v: "Solo tiempo de desarrollo; ningún gasto de infraestructura." },
  { k: "Cero costos operativos", v: "El plan gratuito sostiene la operación mes a mes." },
  { k: "Máxima autonomía", v: "El cliente final administra su negocio sin intermediarios." },
  { k: "Alta replicabilidad", v: "El mismo sistema sirve a rubros muy distintos entre sí." },
];

export function Conclusion() {
  return (
    <Section id="conclusion" className="border-t-2 border-ink">
      <SectionHeader num="12" kicker="CONCLUSIÓN" title="Un negocio escalable sobre cimientos gratuitos" />
      <div className="grid lg:grid-cols-[1.2fr_1fr] gap-10 items-start">
        <div className="reveal">
          <p className="text-[17px] md:text-[19px] leading-relaxed text-ink">
            Esta arquitectura permite construir un{" "}
            <span className="font-semibold box-decoration-clone bg-signal/15 px-1 border-b-2 border-signal">
              negocio escalable de catálogos digitales
            </span>{" "}
            donde cada venta es un entregable completo y autosuficiente.
          </p>
          <div className="mt-8 border-2 border-ink bg-deep text-paper p-6 md:p-7 blueprint-grid-dark">
            <div className="font-mono text-[10.5px] tracking-[0.2em] text-cyanline/70 mb-2">
              VEREDICTO TÉCNICO
            </div>
            <p className="font-display text-[19px] md:text-[21px] font-bold leading-snug" style={{ fontStretch: "115%" }}>
              La combinación <span className="text-signal">Firebase + Vercel + Next.js</span> ofrece la
              relación óptima entre funcionalidad, costo cero y facilidad de mantenimiento para el modelo{" "}
              <span className="text-cyanline">one-time</span>.
            </p>
          </div>
        </div>
        <ul className="reveal space-y-4" style={{ transitionDelay: "120ms" }}>
          {CONCLUSIONES.map((c, i) => (
            <li
              key={c.k}
              className="group grid grid-cols-[auto_1fr] gap-4 items-start border border-ink/25 bg-paper px-5 py-4 transition-all duration-300 hover:border-ink hover:-translate-x-[-4px] hover:bg-paper-2"
              style={{ transitionDelay: `${i * 70}ms` }}
            >
              <span className="w-9 h-9 border-2 border-ink flex items-center justify-center font-mono text-[12px] font-semibold group-hover:bg-ink group-hover:text-paper transition-colors">
                {String(i + 1).padStart(2, "0")}
              </span>
              <div>
                <h3 className="font-display font-bold text-[15.5px]" style={{ fontStretch: "112%" }}>
                  {c.k}
                </h3>
                <p className="mt-0.5 text-[13.5px] text-ink-soft">{c.v}</p>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </Section>
  );
}

/* ---------------- 13 · anexos ---------------- */

const TECHS = [
  { n: "Next.js", d: "Framework de React para web apps", url: "https://nextjs.org/docs" },
  { n: "Firebase", d: "Plataforma de Google para backend", url: "https://firebase.google.com" },
  { n: "Vercel", d: "Plataforma de despliegue y edge", url: "https://vercel.com/docs" },
  { n: "Cloudflare", d: "Gestión de DNS y CDN", url: "https://www.cloudflare.com" },
];

const REFS = [
  { n: "Documentación Firebase", url: "https://firebase.google.com" },
  { n: "Documentación Vercel", url: "https://vercel.com/docs" },
  { n: "Documentación Next.js", url: "https://nextjs.org/docs" },
];

export function Anexos() {
  return (
    <Section id="anexos" className="border-t-2 border-ink bg-paper-2/60">
      <SectionHeader
        num="13"
        kicker="ANEXOS"
        title="Tecnologías y referencias"
      />
      <div className="grid md:grid-cols-[1.3fr_1fr] gap-6">
        <div className="reveal grid sm:grid-cols-2 gap-4">
          {TECHS.map((t) => (
            <a
              key={t.n}
              href={t.url}
              target="_blank"
              rel="noreferrer"
              className="group border-2 border-ink bg-paper p-5 transition-all duration-300 hover:bg-ink hover:text-paper hover:-translate-y-1"
            >
              <div className="flex items-center justify-between">
                <span className="display-heavy text-xl">{t.n}</span>
                <IconArrow className="w-4.5 h-4.5 text-signal-dark group-hover:text-signal group-hover:translate-x-1 transition-all" />
              </div>
              <p className="mt-1.5 text-[13px] text-ink-soft group-hover:text-paper/75 transition-colors">{t.d}</p>
              <span className="mt-3 inline-block font-mono text-[10.5px] tracking-wide text-ink-soft/70 group-hover:text-cyanline transition-colors break-all">
                {t.url.replace("https://", "")} ↗
              </span>
            </a>
          ))}
        </div>
        <div className="reveal border-2 border-ink bg-paper p-6" style={{ transitionDelay: "120ms" }}>
          <h3 className="font-mono text-[11px] font-semibold tracking-[0.22em] text-ink-soft">
            REFERENCIAS DOCUMENTALES
          </h3>
          <ul className="mt-4 divide-y divide-ink/15">
            {REFS.map((r, i) => (
              <li key={r.n}>
                <a
                  href={r.url}
                  target="_blank"
                  rel="noreferrer"
                  className="group flex items-center gap-3 py-3 transition-colors hover:text-signal-dark"
                >
                  <span className="font-mono text-[11px] text-ink-soft/60">[{i + 1}]</span>
                  <span className="font-medium text-[14px] flex-1">{r.n}</span>
                  <IconArrow className="w-4 h-4 text-ink-soft/50 group-hover:text-signal group-hover:translate-x-1 transition-all" />
                </a>
              </li>
            ))}
          </ul>
          <div className="mt-5 border-t border-dashed border-ink/25 pt-4 flex items-center gap-2.5 font-mono text-[11px] text-ink-soft">
            <IconBolt className="w-4 h-4 text-signal-dark" />
            Revisado y aprobado por el equipo de desarrollo · 30 AGO 2026
          </div>
        </div>
      </div>
    </Section>
  );
}

/* ---------------- pie de documento ---------------- */

export function FinDocumento() {
  return (
    <footer className="relative bg-deep text-paper blueprint-grid-dark border-t-2 border-ink overflow-hidden">
      <div className="mx-auto max-w-6xl px-5 md:px-8 py-16 md:py-20 flex flex-col md:flex-row items-center justify-between gap-10">
        <div>
          <div className="font-mono text-[11px] tracking-[0.24em] text-cyanline/70 mb-3">
            ARQ-CAT-2026-001 · v1.0 · HOJA 13/13
          </div>
          <p className="display-heavy text-[clamp(2rem,6vw,4.2rem)] leading-[0.98]">
            Fin del
            <br />
            documento<span className="text-signal">.</span>
          </p>
        </div>
        <div className="flex flex-col items-center gap-6">
          <span className="stamp text-cyanline text-2xl md:text-3xl stamp-animate">Cerrado</span>
          <a
            href="#portada"
            className="group inline-flex items-center gap-3 border-2 border-paper/60 px-5 py-3 font-mono text-[12px] font-semibold tracking-[0.2em] transition-all duration-300 hover:bg-paper hover:text-deep"
          >
            ↑ VOLVER A PORTADA
          </a>
        </div>
      </div>
      <div className="border-t border-cyanline/20">
        <div className="mx-auto max-w-6xl px-5 md:px-8 py-4 flex flex-wrap items-center justify-between gap-3 font-mono text-[10.5px] tracking-[0.16em] text-cyanline/50">
          <span>EQUIPO DE DESARROLLO — 30 AGO 2026</span>
          <span>FIREBASE · VERCEL · NEXT.JS · CLOUDFLARE</span>
          <span>MODELO ONE-TIME · $0/MES</span>
        </div>
      </div>
    </footer>
  );
}
