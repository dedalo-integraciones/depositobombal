import { useScramble, useRevealObserver } from "../hooks";
import { IconArrowDown } from "./Icons";

const TICKER = [
  "NEXT.JS",
  "FIREBASE",
  "VERCEL",
  "CLOUDFLARE",
  "SANGUCHERÍA",
  "FLORERÍA",
  "INMOBILIARIA",
  "MAYORISTA",
  "RESTAURANTE",
  "CONCESIONARIA",
];

function TickerRow() {
  const row = (key: string) => (
    <div key={key} className="flex shrink-0 items-center" aria-hidden={key === "b"}>
      {TICKER.map((t, i) => (
        <span key={t} className="flex items-center">
          <span className="px-6 font-mono text-[12px] font-semibold tracking-[0.28em] text-paper/90">
            {t}
          </span>
          <span className="text-signal text-[13px]">{i % 4 === 3 ? "●" : "✕"}</span>
        </span>
      ))}
    </div>
  );
  return (
    <div className="overflow-hidden border-t-2 border-ink bg-deep py-2.5">
      <div className="ticker-track flex w-max">
        {row("a")}
        {row("b")}
      </div>
    </div>
  );
}

function TitleBlockCell({
  label,
  value,
  accent = false,
  className = "",
}: {
  label: string;
  value: string;
  accent?: boolean;
  className?: string;
}) {
  return (
    <div className={`px-4 py-3 ${className}`}>
      <div className="font-mono text-[9.5px] tracking-[0.22em] text-ink-soft/80">
        {label}
      </div>
      <div
        className={`mt-1 font-mono text-[13px] font-semibold tracking-wide ${
          accent ? "text-signal-dark" : "text-ink"
        }`}
      >
        {value}
      </div>
    </div>
  );
}

function MiniStack() {
  const layers = [
    { name: "Landing page", tag: "PÚBLICA", dot: "bg-mint", shift: "translate-x-0" },
    { name: "Catálogo", tag: "PÚBLICO", dot: "bg-mint", shift: "translate-x-3" },
    { name: "Panel admin", tag: "PRIVADO", dot: "bg-signal", shift: "translate-x-6" },
  ];
  return (
    <div className="col-span-2 px-4 py-4 bg-deep relative overflow-hidden blueprint-grid-dark">
      <div className="font-mono text-[9.5px] tracking-[0.22em] text-cyanline/70 mb-3">
        ENTREGABLES POR CLIENTE
      </div>
      <div className="space-y-2">
        {layers.map((l) => (
          <div
            key={l.name}
            className={`flex items-center justify-between border border-cyanline/30 bg-deep-2 px-3 py-2 ${l.shift} transition-transform duration-300 hover:translate-x-8`}
          >
            <span className="font-display font-bold text-[13px] text-paper" style={{ fontStretch: "112%" }}>
              {l.name}
            </span>
            <span className="flex items-center gap-1.5 font-mono text-[9px] tracking-[0.18em] text-cyanline/80">
              <i className={`w-1.5 h-1.5 rounded-full ${l.dot} inline-block`} />
              {l.tag}
            </span>
          </div>
        ))}
      </div>
      <div className="mt-3 font-mono text-[9.5px] tracking-[0.16em] text-cyanline/50">
        ▸ FIREBASE + VERCEL · $0/MES OPERATIVO
      </div>
    </div>
  );
}

export default function Cover() {
  useRevealObserver();
  const title = useScramble("ARQUITECTURA DE CATÁLOGOS DIGITALES", 250);

  return (
    <header id="portada" className="relative bg-paper blueprint-grid-light border-b-2 border-ink">
      {/* franja superior */}
      <div className="border-b border-ink/15">
        <div className="mx-auto max-w-6xl px-5 md:px-8 py-3 flex items-center justify-between gap-4">
          <span className="cursor-blink font-mono text-[11px] md:text-[12px] font-semibold tracking-[0.24em] text-ink">
            EQUIPO DE DESARROLLO — DOCUMENTO EJECUTIVO
          </span>
          <span className="hidden md:block font-mono text-[11px] tracking-[0.18em] text-ink-soft">
            REF · ARQ-CAT-2026-001
          </span>
        </div>
      </div>

      <div className="mx-auto max-w-6xl px-5 md:px-8 pt-12 md:pt-20 pb-12 md:pb-16 grid lg:grid-cols-[1.45fr_1fr] gap-10 lg:gap-14 items-start">
        {/* columna título */}
        <div>
          <div className="flex flex-wrap items-center gap-3">
            <span className="bg-signal text-paper font-mono text-[11px] font-semibold tracking-[0.2em] px-2.5 py-1">
              ESPECIFICACIÓN v1.0
            </span>
            <span className="font-mono text-[11px] tracking-[0.2em] text-ink-soft">
              30 · AGO · 2026
            </span>
          </div>

          <h1
            className="display-heavy mt-6 text-[clamp(2.6rem,7.2vw,5.4rem)] leading-[0.98] text-ink"
            aria-label="Arquitectura de catálogos digitales"
          >
            {title}
          </h1>

          <p className="mt-6 max-w-xl text-[16px] md:text-[17px] leading-relaxed text-ink-soft">
            Solución tecnológica para crear y vender{" "}
            <strong className="text-ink font-semibold">catálogos digitales personalizados</strong>{" "}
            a pequeños y medianos negocios. Modelo{" "}
            <strong className="text-signal-dark font-semibold">one-time</strong>: pago único por
            cliente, sin costos mensuales recurrentes ni mantenimiento técnico posterior.
          </p>

          <div className="mt-8 flex flex-wrap items-center gap-5">
            <span className="stamp text-signal-dark text-lg md:text-xl stamp-animate">
              Aprobado
            </span>
            <ul className="space-y-1.5">
              {[
                "Pago único por cliente — sin suscripciones",
                "$0/mes de costo operativo para el desarrollador",
                "Despliegue replicable en 1–2 horas",
              ].map((t) => (
                <li key={t} className="flex items-start gap-2.5 text-[13.5px] font-medium text-ink">
                  <svg viewBox="0 0 24 24" className="w-4 h-4 mt-0.5 shrink-0 text-mint" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M4 12.5l5 5L20 6.5" />
                  </svg>
                  {t}
                </li>
              ))}
            </ul>
          </div>

          <a
            href="#resumen"
            className="group mt-10 inline-flex items-center gap-3 font-mono text-[12px] font-semibold tracking-[0.2em] text-ink border-b-2 border-signal pb-1 hover:text-signal-dark transition-colors"
          >
            LEER EL DOCUMENTO
            <IconArrowDown className="w-4 h-4 text-signal group-hover:translate-y-1 transition-transform" />
          </a>
        </div>

        {/* cajetín de plano */}
        <div className="relative">
          <div className="border-2 border-ink bg-paper shadow-[8px_8px_0_0_rgba(14,27,42,0.9)] grid grid-cols-2">
            <TitleBlockCell label="DOCUMENTO" value="ARQ-CAT-2026-001" className="border-r-2 border-b-2 border-ink/70" />
            <TitleBlockCell label="VERSIÓN" value="1.0" className="border-b-2 border-ink/70" />
            <TitleBlockCell label="FECHA" value="30 AGO 2026" className="border-r-2 border-b-2 border-ink/70" />
            <TitleBlockCell label="AUTOR" value="EQ. DESARROLLO" className="border-b-2 border-ink/70" />
            <TitleBlockCell label="MODELO" value="ONE-TIME" accent className="border-r-2 border-b-2 border-ink/70" />
            <TitleBlockCell label="ESTADO" value="APROBADO ✓" accent className="border-b-2 border-ink/70" />
            <MiniStack />
          </div>
          <div className="mt-3 flex items-center justify-between font-mono text-[10px] tracking-[0.2em] text-ink-soft/80">
            <span>ESCALA 1:1</span>
            <span>HOJA 1 / 13</span>
            <span>UNIDAD: USD</span>
          </div>
        </div>
      </div>

      <TickerRow />
    </header>
  );
}
