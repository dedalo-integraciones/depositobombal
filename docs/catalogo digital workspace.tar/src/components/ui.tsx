import React from "react";

export function SectionHeader({
  num,
  kicker,
  title,
  lead,
  dark = false,
}: {
  num: string;
  kicker: string;
  title: string;
  lead?: string;
  dark?: boolean;
}) {
  return (
    <header className="reveal mb-10 md:mb-14">
      <div className="flex items-center gap-4">
        <span
          className={`inline-flex items-center justify-center w-10 h-10 border-2 font-mono text-[13px] font-semibold ${
            dark
              ? "border-cyanline/60 text-cyanline bg-transparent"
              : "border-ink text-ink bg-paper"
          }`}
        >
          {num}
        </span>
        <span
          className={`font-mono text-[11.5px] tracking-[0.22em] ${
            dark ? "text-cyanline/80" : "text-signal-dark"
          }`}
        >
          {kicker}
        </span>
        <span
          className={`hidden sm:block flex-1 h-px ${
            dark ? "bg-cyanline/25" : "bg-ink/20"
          }`}
        />
      </div>
      <h2
        className={`display-heavy mt-5 text-[clamp(1.9rem,4.6vw,3.4rem)] leading-[1.02] ${
          dark ? "text-paper" : "text-ink"
        }`}
      >
        <span className="line-mask">
          <span>{title}</span>
        </span>
      </h2>
      {lead && (
        <p
          className={`mt-4 max-w-2xl text-[15.5px] md:text-base leading-relaxed ${
            dark ? "text-cyanline/75" : "text-ink-soft"
          }`}
        >
          {lead}
        </p>
      )}
    </header>
  );
}

export function Section({
  id,
  children,
  className = "",
  dark = false,
}: {
  id: string;
  children: React.ReactNode;
  className?: string;
  dark?: boolean;
}) {
  return (
    <section
      id={id}
      className={`scroll-mt-24 relative ${
        dark ? "bg-deep text-paper blueprint-grid-dark" : ""
      } ${className}`}
    >
      <div className="mx-auto max-w-6xl px-5 md:px-8 py-16 md:py-24">{children}</div>
    </section>
  );
}

export function MonoTag({
  children,
  tone = "ink",
}: {
  children: React.ReactNode;
  tone?: "ink" | "signal" | "mint" | "cyan";
}) {
  const tones: Record<string, string> = {
    ink: "border-ink/40 text-ink",
    signal: "border-signal/60 text-signal-dark",
    mint: "border-mint/60 text-mint",
    cyan: "border-cyanline/50 text-cyanline",
  };
  return (
    <span
      className={`inline-block border px-2 py-0.5 font-mono text-[10.5px] font-semibold tracking-[0.14em] uppercase ${tones[tone]}`}
    >
      {children}
    </span>
  );
}
