import { useRevealObserver, useScrollProgress, useScrollSpy, useScrolledPast } from "./hooks";
import Cover from "./components/Cover";
import { Resumen, Objetivos, Arquitectura } from "./components/SectionsCore";
import { Componentes, EstructuraDatos, Flujos } from "./components/SectionsOps";
import { Costos, Rubros, Ventajas } from "./components/SectionsBiz";
import { Seguridad, Roadmap, Conclusion, Anexos, FinDocumento } from "./components/SectionsEnd";
import { IconDoc } from "./components/Icons";

const TOC = [
  { id: "resumen", n: "01", t: "Resumen ejecutivo" },
  { id: "objetivos", n: "02", t: "Objetivos" },
  { id: "arquitectura", n: "03", t: "Arquitectura general" },
  { id: "componentes", n: "04", t: "Componentes" },
  { id: "datos", n: "05", t: "Estructura de datos" },
  { id: "flujos", n: "06", t: "Flujo de trabajo" },
  { id: "costos", n: "07", t: "Modelo de costos" },
  { id: "rubros", n: "08", t: "Adaptabilidad" },
  { id: "ventajas", n: "09", t: "Ventajas" },
  { id: "seguridad", n: "10", t: "Seguridad" },
  { id: "roadmap", n: "11", t: "Roadmap" },
  { id: "conclusion", n: "12", t: "Conclusión" },
  { id: "anexos", n: "13", t: "Anexos" },
];

function ProgressBar() {
  const p = useScrollProgress();
  return (
    <div className="fixed top-0 left-0 right-0 h-[3.5px] z-[90] bg-transparent pointer-events-none">
      <div
        className="h-full bg-signal origin-left"
        style={{ transform: `scaleX(${p})` }}
        aria-hidden
      />
    </div>
  );
}

function MiniHeader() {
  const show = useScrolledPast(640);
  const p = useScrollProgress();
  return (
    <div
      className={`fixed top-0 left-0 right-0 z-[85] transition-transform duration-500 ${
        show ? "translate-y-0" : "-translate-y-full"
      }`}
    >
      <div className="bg-deep/95 backdrop-blur-sm border-b border-cyanline/25">
        <div className="mx-auto max-w-6xl px-5 md:px-8 py-2.5 flex items-center justify-between gap-4">
          <span className="flex items-center gap-2.5 font-mono text-[11px] font-semibold tracking-[0.18em] text-paper">
            <IconDoc className="w-4 h-4 text-signal" />
            ARQ-CAT-2026-001
          </span>
          <span className="hidden sm:block font-mono text-[10.5px] tracking-[0.16em] text-cyanline/70">
            ARQUITECTURA DE CATÁLOGOS DIGITALES
          </span>
          <span className="font-mono text-[11px] font-semibold text-signal">
            {Math.round(p * 100)}%
          </span>
        </div>
      </div>
    </div>
  );
}

function Rail() {
  const active = useScrollSpy(TOC.map((t) => t.id));
  return (
    <aside className="hidden xl:flex fixed left-0 top-0 bottom-0 w-[232px] z-[60] flex-col border-r-2 border-ink bg-paper">
      <div className="px-5 pt-7 pb-5 border-b-2 border-ink">
        <div className="flex items-center gap-2.5">
          <span className="w-8 h-8 bg-ink flex items-center justify-center">
            <span className="w-3.5 h-3.5 bg-signal inline-block" />
          </span>
          <div>
            <div className="display-heavy text-[15px] leading-none">CATÁLOGOS</div>
            <div className="font-mono text-[9px] tracking-[0.22em] text-ink-soft mt-1">
              DOC EJECUTIVO · v1.0
            </div>
          </div>
        </div>
      </div>
      <nav className="flex-1 overflow-y-auto py-4" aria-label="Índice del documento">
        <div className="px-5 pb-2 font-mono text-[9.5px] tracking-[0.24em] text-ink-soft/70">
          ÍNDICE
        </div>
        {TOC.map((s) => {
          const isActive = active === s.id;
          return (
            <a
              key={s.id}
              href={`#${s.id}`}
              className={`group flex items-baseline gap-3 px-5 py-[7px] text-[12.5px] font-medium transition-all duration-200 border-l-[3px] ${
                isActive
                  ? "border-signal bg-signal/10 text-ink font-semibold"
                  : "border-transparent text-ink-soft hover:text-ink hover:border-ink/30 hover:translate-x-0.5"
              }`}
            >
              <span
                className={`font-mono text-[10px] font-semibold ${
                  isActive ? "text-signal-dark" : "text-ink-soft/60"
                }`}
              >
                {s.n}
              </span>
              <span className="truncate">{s.t}</span>
            </a>
          );
        })}
      </nav>
      <div className="px-5 py-5 border-t-2 border-ink bg-paper-2/70">
        <div className="flex items-center justify-between">
          <span className="font-mono text-[9.5px] tracking-[0.2em] text-ink-soft">COSTO OPERATIVO</span>
          <span className="display-heavy text-xl text-signal-dark leading-none">$0</span>
        </div>
        <div className="mt-2 flex items-center gap-2">
          <i className="w-1.5 h-1.5 rounded-full bg-mint inline-block animate-pulse-dot" style={{ animation: "pulsedot 2.2s ease-in-out infinite" }} />
          <span className="font-mono text-[9.5px] tracking-[0.14em] text-ink-soft">SISTEMA OPERATIVO</span>
        </div>
      </div>
    </aside>
  );
}

export default function App() {
  useRevealObserver();

  return (
    <div className="relative min-h-screen bg-paper text-ink">
      <div className="noise-overlay" aria-hidden />
      <ProgressBar />
      <MiniHeader />
      <Rail />

      <div className="xl:pl-[232px]">
        <Cover />
        <main>
          <Resumen />
          <Objetivos />
          <Arquitectura />
          <Componentes />
          <EstructuraDatos />
          <Flujos />
          <Costos />
          <Rubros />
          <Ventajas />
          <Seguridad />
          <Roadmap />
          <Conclusion />
          <Anexos />
        </main>
        <FinDocumento />
      </div>
    </div>
  );
}
